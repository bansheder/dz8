<?php
ini_set('display_errors', 'On');
error_reporting(E_ALL);
require_once 'db.php';

$result = $conn->query("SELECT id, name FROM regions");
$regions = [];
while ($row = $result->fetch_assoc()) {
    $regions[] = $row;
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Зависимые выпадающие списки</title>
    <script src="jquery-3.6.0.min.js"></script>
</head>
<body>
    <h1>Выберите регион и город</h1>
    <form>
        <label for="region">Регион:</label>
        <select id="region">
            <option value="0">-выберите регион-</option>
            <?php foreach ($regions as $region): ?>
                <option value="<?= $region['id'] ?>"><?= htmlspecialchars($region['name']) ?></option>
            <?php endforeach; ?>
        </select>
        <label for="city" style="display: none;">Город:</label>
        <select id="city" style="display: none;"></select>
    </form>

    <script>
        $(document).ready(function () {
            $('#region').on('change', function () {
                const regionId = $(this).val();
                if (regionId === "0") {
                    $('#city').hide().empty();
                    $('label[for="city"]').hide();
                    return;
                }

                $.ajax({
                    url: 'get.php',
                    type: 'GET',
                    data: { region_id: regionId },
                    success: function (data) {
                        const cities = JSON.parse(data);
                        let cityOptions = '<option value="0">-выберите город-</option>';
                        cities.forEach(city => {
                            cityOptions += `<option value="${city.id}">${city.name}</option>`;
                        });
                        $('#city').html(cityOptions).show();
                        $('label[for="city"]').show();
                    }
                });
            });
        });
    </script>
</body>
</html>
